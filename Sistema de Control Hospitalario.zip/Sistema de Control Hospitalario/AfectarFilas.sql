INSERT INTO Medicos(nombres, exequatur ,especialidad)
VALUES('Jose' ,'NS','Cirujano')


