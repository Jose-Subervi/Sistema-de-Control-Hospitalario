create database Proyect

use Proyect

create table Registros
(
ID int identity (1,1),
Nombre varchar(20) not null,
Contrase�a varbinary(max) not null
)

select * from Registros

create table Medicos
(
ID int identity (1,1),
Nombre varchar(20) not null,
Exequatur varchar(30) not null,
Especialidad varchar(30) not null
)

select * from Medicos
