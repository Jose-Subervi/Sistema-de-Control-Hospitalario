/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [id]
      ,[Doctor]
      ,[Fecha]
  FROM [Proyect].[dbo].[Citas]


 INSERT INTO Citas (Doctor, Fecha) VALUES ('Jose', '7/10/2000')

 select * from Citas 