﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal.CSS
{
    class PacientesCSS
    {
        private int id { get; set; }
        private string nombre { get; set; }
        private int cedula { get; set; }
        private string aseguradora { get; set; }

        public int ID { get { return id; } set { id = value; } }
        public string Nombre { get { return nombre; } set { nombre = value; } }
        public int Cedula { get { return cedula; } set { cedula = value; } }
        public string Aseguradora { get { return aseguradora; } set { aseguradora = value; } }
    }
}
