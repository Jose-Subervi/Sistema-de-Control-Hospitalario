﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal.CSS
{
    class CitasMedicasCSS
    {
        private int id { get; set; }
        private string doctor { get; set; }
        private string fecha { get; set; }

        public int ID { get { return id; } set { id = value; } }
        public string Doctor { get { return doctor; } set { doctor = value; } }
        public string Fecha { get { return fecha; } set { fecha = value; } }
    }
}
