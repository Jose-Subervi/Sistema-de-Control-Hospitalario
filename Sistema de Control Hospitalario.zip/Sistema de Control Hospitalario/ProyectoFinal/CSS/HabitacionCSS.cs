﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal.CSS
{
    class HabitacionCSS
    {
        private int id { get; set; }
        private int numero { get; set; }
        private string tipo { get; set; }
        private int precio { get; set; }

        public int ID { get { return id; } set { id = value; } }
        public int Numero { get { return numero; } set { numero = value; } }
        public string Tipo { get { return tipo; } set { tipo = value; } }
        public int Precio { get { return precio; } set { precio = value; } }
    }
}
