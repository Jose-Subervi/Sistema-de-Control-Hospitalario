﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal.CSS
{
    class MedicosCSS
    {
        private int id { get; set; }
        private string nombre { get; set; }
        private string exequatur { get; set; }
        private string especialidad { get; set; }

        public int ID { get { return id; } set { id = value; } }
        public string Nombre { get { return nombre; } set { nombre = value; } }
        public string Exequatur { get { return exequatur; } set { exequatur = value; } }
        public string Especialidad { get { return especialidad; } set { especialidad = value; } }

    }
}
