﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal.CSS
{
    class AltasMedicasCSS
    {
        private int id { get; set; }
        private int precio { get; set; }
        private string fecha_salida { get; set; }
        private string fecha_ingreso { get; set; }
        private string paciente { get; set; }
        private int habitacion { get; set; }
        private double precio_total { get; set; }



        public int ID { get { return id; } set { id = value; } }
        public int Precio { get { return precio; } set { precio = value; } }
        public string Fecha_salida { get { return fecha_salida; } set { fecha_salida = value; } }
        public string Fecha_ingreso { get { return fecha_ingreso; } set { fecha_ingreso = value; } }
        public string Paciente { get { return paciente; } set { paciente = value; } }
        public int Habitacion { get { return habitacion; } set { habitacion = value; } }
        public double Precio_total { get { return precio_total; } set { precio_total = value; } }

    }
}
