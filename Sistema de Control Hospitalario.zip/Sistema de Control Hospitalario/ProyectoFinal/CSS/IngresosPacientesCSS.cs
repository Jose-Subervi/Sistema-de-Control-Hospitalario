﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal.CSS
{
    class IngresosPacientesCSS
    {
        private int id { get; set; }
        private string paciente { get; set; }
        private string habitacion { get; set; }
        private string fecha { get; set; }

        public int ID { get { return id; } set { id = value; } }
        public string Paciente { get { return paciente; } set { paciente = value; } }
        public string Habitacion { get { return habitacion; } set { habitacion = value; } }
        public string Fecha { get { return fecha; } set { fecha = value; } }
    }
}
