﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using ProyectoFinal.CSS;

namespace ProyectoFinal.DAL
{
    class MedicosDAL
    {
        ConexionDAL conexion;

        public MedicosDAL()
        {
            conexion = new ConexionDAL();
        }

        public bool Agregar(MedicosCSS oMedicosCSS)
        {
           return conexion.ECSRD("INSERT INTO Medicos (nombres, exequatur, especialidad) VALUES ('" + oMedicosCSS.Nombre +"', '"+oMedicosCSS.Exequatur +"', '"+oMedicosCSS.Especialidad+"')");

        }

        public int Eliminar(MedicosCSS oMedicosCSS)
        {
             conexion.ECSRD("DELETE FROM Medicos WHERE ID="+oMedicosCSS.ID);

            return 1;

        }

        public int Modificar(MedicosCSS oMedicosCSS)
        {
            conexion.ECSRD("UPDATE Medicos SET nombres='"+oMedicosCSS.Nombre+"' WHERE ID=" + oMedicosCSS.ID);
            conexion.ECSRD("UPDATE Medicos SET exequatur='" + oMedicosCSS.Exequatur + "' WHERE ID=" + oMedicosCSS.ID);
            conexion.ECSRD("UPDATE Medicos SET especialidad='" + oMedicosCSS.Especialidad + "' WHERE ID=" + oMedicosCSS.ID);


            return 1;

        }

        public DataSet MostrarMedicos()
        {
            SqlCommand sentencia = new SqlCommand("SELECT * FROM Medicos");

            return conexion.EjecutarSentencia(sentencia);
        }
    }
}
