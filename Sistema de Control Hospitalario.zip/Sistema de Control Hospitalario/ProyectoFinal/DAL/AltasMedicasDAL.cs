﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProyectoFinal.CSS;

namespace ProyectoFinal.DAL
{
    class AltasMedicasDAL
    {
        ConexionDAL conexion;

        public AltasMedicasDAL()
        {
            conexion = new ConexionDAL();
        }

        public bool Agregar(AltasMedicasCSS oAltasMedicasCSS)
        {
            return conexion.ECSRD("INSERT INTO Altas (Fecha_salida, Precio, Fecha_ingreso, Paciente, Habitacion, Precio_Total) VALUES ('" + oAltasMedicasCSS.Fecha_salida + "','" + oAltasMedicasCSS.Precio + "','" + oAltasMedicasCSS.Fecha_ingreso + "','" + oAltasMedicasCSS.Paciente + "','" + oAltasMedicasCSS.Habitacion + "','" + oAltasMedicasCSS.Precio_total + "')");

        }

        public int Eliminar(AltasMedicasCSS oAltasMedicasCSS)
        {
            conexion.ECSRD("DELETE FROM Altas WHERE ID=" + oAltasMedicasCSS.ID);

            return 1;
        }


        public int Modificar(AltasMedicasCSS oAltasMedicasCSS)
        {
            conexion.ECSRD("UPDATE Altas SET Fecha_ingreso='" + oAltasMedicasCSS.Fecha_ingreso + "' WHERE ID=" + oAltasMedicasCSS.ID);
            conexion.ECSRD("UPDATE Altas SET Paciente='" + oAltasMedicasCSS.Paciente + "' WHERE ID=" + oAltasMedicasCSS.ID);
            conexion.ECSRD("UPDATE Altas SET Habitacion='" + oAltasMedicasCSS.Habitacion + "' WHERE ID=" + oAltasMedicasCSS.ID);
            conexion.ECSRD("UPDATE Altas SET Fecha_salida='" + oAltasMedicasCSS.Fecha_salida + "' WHERE ID=" + oAltasMedicasCSS.ID);
            conexion.ECSRD("UPDATE Altas SET Precio='" + oAltasMedicasCSS.Precio + "' WHERE ID=" + oAltasMedicasCSS.ID);
            conexion.ECSRD("UPDATE Altas SET Precio_Total='" + oAltasMedicasCSS.Precio_total + "' WHERE ID=" + oAltasMedicasCSS.ID);


            return 1;

        }

        public DataSet MostrarPacientes()
        {
            SqlCommand sentencia = new SqlCommand("SELECT * FROM Altas");

            return conexion.EjecutarSentencia(sentencia);
        }

        public DataSet MostrarPacientes2()
        {
            SqlCommand sentencia = new SqlCommand("SELECT * FROM Ingresos");

            return conexion.EjecutarSentencia(sentencia);
        }
    }
}
