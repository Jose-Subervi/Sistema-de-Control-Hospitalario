﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProyectoFinal.CSS;

namespace ProyectoFinal.DAL
{
    class IngresosPacientesDAL
    {
        ConexionDAL conexion;

        public IngresosPacientesDAL()
        {
            conexion = new ConexionDAL();
        }

        public bool Agregar(IngresosPacientesCSS oIngresosPacientesCSS)
        {
            return conexion.ECSRD("INSERT INTO Ingresos (Paciente, Habitacion, Fecha_Inicio) VALUES ('" + oIngresosPacientesCSS.Paciente + "', '" + oIngresosPacientesCSS.Habitacion + "','" + oIngresosPacientesCSS.Fecha + "')");

        }

        public int Eliminar(IngresosPacientesCSS oIngresosPacientesCSS)
        {
            conexion.ECSRD("DELETE FROM Ingresos WHERE ID=" + oIngresosPacientesCSS.ID);

            return 1;
        }


        public int Modificar(IngresosPacientesCSS oIngresosPacientesCSS)
        {
            conexion.ECSRD("UPDATE Ingresos SET Paciente='" + oIngresosPacientesCSS.Paciente + "' WHERE ID=" + oIngresosPacientesCSS.ID);
            conexion.ECSRD("UPDATE Ingresos SET Habitacion='" + oIngresosPacientesCSS.Habitacion + "' WHERE ID=" + oIngresosPacientesCSS.ID);
            conexion.ECSRD("UPDATE Ingresos SET Fecha_Inicio='" + oIngresosPacientesCSS.Fecha + "' WHERE ID=" + oIngresosPacientesCSS.ID);


            return 1;

        }

        public DataSet MostrarPacientes()
        {
            SqlCommand sentencia = new SqlCommand("SELECT * FROM Ingresos");

            return conexion.EjecutarSentencia(sentencia);
        }
    }
}
