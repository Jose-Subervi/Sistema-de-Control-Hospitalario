﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProyectoFinal.CSS;

namespace ProyectoFinal.DAL
{
    class CitasMedicasDAL
    {
        ConexionDAL conexion;

        public CitasMedicasDAL()
        {
            conexion = new ConexionDAL();
        }

        public bool Agregar(CitasMedicasCSS oCitasMedicasCSS)
        {
            return conexion.ECSRD("INSERT INTO Citas (Doctor, Fecha) VALUES ('" + oCitasMedicasCSS.Doctor + "', '" + oCitasMedicasCSS.Fecha + "')");

        }

        public int Eliminar(CitasMedicasCSS oCitasMedicasCSS)
        {
            conexion.ECSRD("DELETE FROM Citas WHERE ID=" + oCitasMedicasCSS.ID);

            return 1;
        }


        public int Modificar(CitasMedicasCSS oCitasMedicasCSS)
        {
            conexion.ECSRD("UPDATE Citas SET Doctor='" + oCitasMedicasCSS.Doctor + "' WHERE ID=" + oCitasMedicasCSS.ID);
            conexion.ECSRD("UPDATE Citas SET Fecha='" + oCitasMedicasCSS.Fecha + "' WHERE ID=" + oCitasMedicasCSS.ID);

            return 1;

        }

        public DataSet MostrarPacientes()
        {
            SqlCommand sentencia = new SqlCommand("SELECT * FROM Citas");

            return conexion.EjecutarSentencia(sentencia);
        }
    }
}
