﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProyectoFinal.CSS;

namespace ProyectoFinal.DAL
{
    class PacientesDAL
    {
        ConexionDAL conexion;

        public PacientesDAL()
        {
            conexion = new ConexionDAL();
        }

        public bool Agregar(PacientesCSS oPacientesCSS)
        {
            return conexion.ECSRD("INSERT INTO Pacientes (nombre, cedula, asegurado) VALUES ('" + oPacientesCSS.Nombre + "', '" + oPacientesCSS.Cedula + "', '" + oPacientesCSS.Aseguradora + "')");

        }

        public int Eliminar(PacientesCSS opacientesCSS)
        {
            conexion.ECSRD("DELETE FROM Pacientes WHERE ID=" + opacientesCSS.ID);

            return 1;
        }


        public int Modificar(PacientesCSS oPacientesCSS)
        {
            conexion.ECSRD("UPDATE Pacientes SET nombre='" + oPacientesCSS.Nombre + "' WHERE ID=" + oPacientesCSS.ID);
            conexion.ECSRD("UPDATE Pacientes SET cedula='" + oPacientesCSS.Cedula + "' WHERE ID=" + oPacientesCSS.ID);
            conexion.ECSRD("UPDATE Pacientes SET asegurado='" + oPacientesCSS.Aseguradora + "' WHERE ID=" + oPacientesCSS.ID);


            return 1;

        }

        public DataSet MostrarPacientes()
        {
            SqlCommand sentencia = new SqlCommand("SELECT * FROM Pacientes");

            return conexion.EjecutarSentencia(sentencia);
        }

    }
}
