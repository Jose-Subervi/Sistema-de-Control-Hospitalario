﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProyectoFinal.CSS;

namespace ProyectoFinal.DAL
{
    class HabitacionDAL
    {
        ConexionDAL conexion;

        public HabitacionDAL()
        {
            conexion = new ConexionDAL();
        }

        public bool Agregar(HabitacionCSS oHabitacionCSS)
        {
            return conexion.ECSRD("INSERT INTO Habitaciones (numero, tipo, precio) VALUES ('" + oHabitacionCSS.Numero + "', '" + oHabitacionCSS.Tipo + "', '" + oHabitacionCSS.Precio + "')");

        }

        public int Eliminar(HabitacionCSS oHabitacionCSS)
        {
            conexion.ECSRD("DELETE FROM Habitaciones WHERE ID=" + oHabitacionCSS.ID);

            return 1;
        }


        public int Modificar(HabitacionCSS oHabitacionCSS)
        {
            conexion.ECSRD("UPDATE Habitaciones SET numero='" + oHabitacionCSS.Numero + "' WHERE ID=" + oHabitacionCSS.ID);
            conexion.ECSRD("UPDATE Habitaciones SET tipo='" + oHabitacionCSS.Tipo + "' WHERE ID=" + oHabitacionCSS.ID);
            conexion.ECSRD("UPDATE Habitaciones SET precio='" + oHabitacionCSS.Precio + "' WHERE ID=" + oHabitacionCSS.ID);


            return 1;

        }

        public DataSet MostrarPacientes()
        {
            SqlCommand sentencia = new SqlCommand("SELECT * FROM Habitaciones");

            return conexion.EjecutarSentencia(sentencia);
        }
    }
}
