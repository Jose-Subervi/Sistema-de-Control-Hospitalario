﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            try { 
            timer1.Start();
            if (CDU.Autentificar(txtUsuario.Text, txtContraseña.Text) > 0)
            {
                progressBar1.Minimum = 1;
                progressBar1.Maximum = 100;
                progressBar1.Step = 2;

                for (int i = 0; i < 100; i++)
                {
                    progressBar1.PerformStep();
                }

                if (progressBar1.Value == 100)
                {
                    progressBar1.Visible = true;
                    MessageBox.Show("Accediendo a Formulario....");
                    txtFinalizado.Visible = true;
                    txtUsuario.Text = "";
                    txtContraseña.Text = "";

                    Program.form1.Hide();
                    Principal frm = new Principal();
                    frm.ShowDialog();
                }

                }
            else { MessageBox.Show("El Usuario o Contraseña esta incorrecto, intentelo de nuevo."); }
            }
            catch
            {
                MessageBox.Show("El Usuario o Contraseña esta incorrecto, intentelo de nuevo.");
            }


        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            Program.form1.Hide();
            Registro frm = new Registro();
            frm.Show();
        }


    }
    
}
