﻿using ProyectoFinal.HPM;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
            Medicos frm = new Medicos();
            frm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
            Pacientes frm = new Pacientes();
            frm.Show();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
            Habitaciones frm = new Habitaciones();
            frm.Show();
        }


        private void button4_Click(object sender, EventArgs e)
        {
            Close();
            Principal2 frm = new Principal2();
            frm.Show();
        }
    }
}
