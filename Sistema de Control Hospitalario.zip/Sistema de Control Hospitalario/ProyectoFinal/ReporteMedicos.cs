﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public partial class ReporteMedicos : Form
    {
        public ReporteMedicos()
        {
            InitializeComponent();
        }

        private void ReporteMedicos_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'DataSetMedicos.Medicos' Puede moverla o quitarla según sea necesario.
            this.MedicosTableAdapter.Fill(this.DataSetMedicos.Medicos);

            this.reportViewer1.RefreshReport();
        }
    }
}
