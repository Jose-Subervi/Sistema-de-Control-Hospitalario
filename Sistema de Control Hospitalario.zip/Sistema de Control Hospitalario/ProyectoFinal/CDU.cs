﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace ProyectoFinal
{
    class CDU
    {
        public static int CrearCuentas(string pUsuario, string pContraseña)
        {
            int resultado = 0;
            SqlConnection cone = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");
            cone.Open();

            SqlCommand Comando = new SqlCommand(string.Format("Insert Into Registros(Nombre, Contraseña) values ('{0}', pwdEncrypt('{1}') )", pUsuario, pContraseña), cone);

            resultado = Comando.ExecuteNonQuery();
            cone.Close();

            return resultado;
        }

        public static int Autentificar(string pUsuario, string pContraseña)
        {
            int resultado = -1;
            SqlConnection cone = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");
            cone.Open();

            SqlCommand Comando = new SqlCommand(string.Format("Select * From Registros WHERE Nombre = '{0}' and PwdCompare('{1}', Contraseña) = 1", pUsuario, pContraseña), cone);

            SqlDataReader reader = Comando.ExecuteReader();

            while (reader.Read())
            {
                resultado = 50;
            }
            cone.Close();
            return resultado;
        }
    }
}
