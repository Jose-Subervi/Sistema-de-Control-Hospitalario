﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProyectoFinal.CSS;
using ProyectoFinal.DAL;

namespace ProyectoFinal.HPM
{
    public partial class CitasMedicas : Form
    {
        CitasMedicasDAL oCitasMedicasCSS;
        public CitasMedicas()
        {
            oCitasMedicasCSS = new CitasMedicasDAL();
            InitializeComponent();
            dataGridView1.DataSource = oCitasMedicasCSS.MostrarPacientes().Tables[0];
        }

        private void CitasMedicas_Load(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");
            SqlCommand cm = new SqlCommand("select nombres from Medicos", cn);
            cn.Open();
            SqlDataReader registro = cm.ExecuteReader();
            while (registro.Read())
            {
                cbxDoctor.Items.Add(registro["nombres"].ToString());
            }
            cn.Close();

        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            oCitasMedicasCSS.Agregar(RecuperarInformacion());
            dataGridView1.DataSource = oCitasMedicasCSS.MostrarPacientes().Tables[0];

        }

        private CitasMedicasCSS RecuperarInformacion()
        {
            CitasMedicasCSS oCitasMedicasCSS = new CitasMedicasCSS();

            int ID = 0; int.TryParse(txtID.Text, out ID);
            oCitasMedicasCSS.ID = ID;
            oCitasMedicasCSS.Doctor = cbxDoctor.Text;
            oCitasMedicasCSS.Fecha = this.dateTimePicker1.Text;

            

            txtID.Text = " ";
            cbxDoctor.Text = " ";



            return oCitasMedicasCSS;


        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = oCitasMedicasCSS.MostrarPacientes().Tables[0];
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            oCitasMedicasCSS.Modificar(RecuperarInformacion());
            dataGridView1.DataSource = oCitasMedicasCSS.MostrarPacientes().Tables[0];
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            oCitasMedicasCSS.Eliminar(RecuperarInformacion());
            dataGridView1.DataSource = oCitasMedicasCSS.MostrarPacientes().Tables[0];
        }

        private void Seleccionar(object sender, DataGridViewCellMouseEventArgs e)
        {
            int indice = e.RowIndex;

            txtID.Text = dataGridView1.Rows[indice].Cells[0].Value.ToString();
            cbxDoctor.Text = dataGridView1.Rows[indice].Cells[1].Value.ToString();
           

        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            Close();
            Principal2 frm = new Principal2();
            frm.Show();
        }

        private void txtBuscarF_TextChanged(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");

            conexion.Open();

            SqlCommand cmd = conexion.CreateCommand();

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM Citas WHERE Doctor like ('" + txtBuscarD.Text + "%')";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);

            dataGridView1.DataSource = dt;

            conexion.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");

            conexion.Open();

            

            string CadenaSQL = "SELECT * FROM Citas WHERE Fecha BETWEEN '" + dateTimePicker2.Text + "' AND '" + dateTimePicker3.Text +"' ";


            SqlDataAdapter adaptador = new SqlDataAdapter(CadenaSQL, conexion);
            DataSet DS = new DataSet();

            adaptador.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];

            conexion.Close(); 
        }

        private void btnReporte_Click(object sender, EventArgs e)
        {
            ReporteCitasMedicas frm = new ReporteCitasMedicas();
            frm.Show();
        }
    }
}
