﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProyectoFinal.CSS;
using ProyectoFinal.DAL;

namespace ProyectoFinal.HPM
{
    public partial class IngresosPacientes : Form
    {
        IngresosPacientesDAL oIngresosPacientesCSS;

        public IngresosPacientes()
        {
            oIngresosPacientesCSS = new IngresosPacientesDAL();
            InitializeComponent();
            dataGridView1.DataSource = oIngresosPacientesCSS.MostrarPacientes().Tables[0];
        }

        private void IngresosPacientes_Load(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");
            SqlCommand cm = new SqlCommand("select nombre from Pacientes", cn);
            cn.Open();
            SqlDataReader registro = cm.ExecuteReader();
            while (registro.Read())
            {
                cbxPaciente.Items.Add(registro["nombre"].ToString());
            }
            cn.Close();

            SqlConnection cnn = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");
            SqlCommand cmm = new SqlCommand("select numero from Habitaciones", cnn);
            cnn.Open();
            SqlDataReader registros = cmm.ExecuteReader();
            while (registros.Read())
            {
                cbxHabitacion.Items.Add(registros["numero"].ToString());
            }
            cnn.Close();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            oIngresosPacientesCSS.Agregar(RecuperarInformacion());
            dataGridView1.DataSource = oIngresosPacientesCSS.MostrarPacientes().Tables[0];
        }

        private IngresosPacientesCSS RecuperarInformacion()
        {
            IngresosPacientesCSS oIngresosPacientesCSS = new IngresosPacientesCSS();

            int ID = 0; int.TryParse(txtID.Text, out ID);
            oIngresosPacientesCSS.ID = ID;
            oIngresosPacientesCSS.Paciente = cbxPaciente.Text;
            oIngresosPacientesCSS.Habitacion = cbxHabitacion.Text;
            oIngresosPacientesCSS.Fecha = this.dateTimePicker1.Text;



            txtID.Text = " ";
            cbxPaciente.Text = " ";
            cbxHabitacion.Text = " ";


            return oIngresosPacientesCSS;


        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = oIngresosPacientesCSS.MostrarPacientes().Tables[0];
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            oIngresosPacientesCSS.Modificar(RecuperarInformacion());
            dataGridView1.DataSource = oIngresosPacientesCSS.MostrarPacientes().Tables[0];
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            oIngresosPacientesCSS.Eliminar(RecuperarInformacion());
            dataGridView1.DataSource = oIngresosPacientesCSS.MostrarPacientes().Tables[0];
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            Close();
            Principal2 frm = new Principal2();
            frm.Show();
        }


        private void Seleccionar(object sender, DataGridViewCellMouseEventArgs e)
        {
            int indice = e.RowIndex;

            txtID.Text = dataGridView1.Rows[indice].Cells[0].Value.ToString();
            cbxPaciente.Text = dataGridView1.Rows[indice].Cells[1].Value.ToString();
            cbxHabitacion.Text = dataGridView1.Rows[indice].Cells[2].Value.ToString();

        }

        private void txtBuscarH_TextChanged(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");

            conexion.Open();

            SqlCommand cmd = conexion.CreateCommand();

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM Ingresos WHERE Habitacion like ('" + txtBuscarH.Text + "%')";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);

            dataGridView1.DataSource = dt;

            conexion.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");

            conexion.Open();



            string CadenaSQL = "SELECT * FROM Ingresos WHERE Fecha_Inicio BETWEEN '" + dateTimePicker2.Text + "' AND '" + dateTimePicker3.Text + "' ";


            SqlDataAdapter adaptador = new SqlDataAdapter(CadenaSQL, conexion);
            DataSet DS = new DataSet();

            adaptador.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];

            conexion.Close();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            ReporteIngresosPacientes frm = new ReporteIngresosPacientes();
            frm.Show();
        }
    }
}
