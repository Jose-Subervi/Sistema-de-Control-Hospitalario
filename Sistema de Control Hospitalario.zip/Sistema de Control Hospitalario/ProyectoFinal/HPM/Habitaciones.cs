﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProyectoFinal.CSS;
using ProyectoFinal.DAL;

namespace ProyectoFinal.HPM
{
    public partial class Habitaciones : Form
    {
        HabitacionDAL oHabitacionCSS;
        public Habitaciones()
        {
            oHabitacionCSS = new HabitacionDAL();
            InitializeComponent();
            cbxTipo.Items.Add("Doble");
            cbxTipo.Items.Add("Privada");
            cbxTipo.Items.Add("Suite");
            dataGridView1.DataSource = oHabitacionCSS.MostrarPacientes().Tables[0]; 
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            Close();
            Principal frm = new Principal();
            frm.Show();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            oHabitacionCSS.Agregar(RecuperarInformacion());
            dataGridView1.DataSource = oHabitacionCSS.MostrarPacientes().Tables[0];
        }

        private HabitacionCSS RecuperarInformacion()
        {
            HabitacionCSS oHabitacionCSS = new HabitacionCSS();

            int ID = 0; int.TryParse(txtID.Text, out ID);
            int Numero = 0; int.TryParse(txtNumero.Text, out Numero);
            int Precio = 0; int.TryParse(txtPrecio.Text, out Precio);
            oHabitacionCSS.ID = ID;
            oHabitacionCSS.Numero = Numero;
            oHabitacionCSS.Tipo = cbxTipo.Text;
            oHabitacionCSS.Precio = Precio;

            txtID.Text = " ";
            txtNumero.Text = " ";
            cbxTipo.Text = " ";
            txtPrecio.Text = " ";


            return oHabitacionCSS;


        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = oHabitacionCSS.MostrarPacientes().Tables[0];

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            oHabitacionCSS.Modificar(RecuperarInformacion());
            dataGridView1.DataSource = oHabitacionCSS.MostrarPacientes().Tables[0];
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            oHabitacionCSS.Eliminar(RecuperarInformacion());
            dataGridView1.DataSource = oHabitacionCSS.MostrarPacientes().Tables[0];
        }

        private void Seleccionar(object sender, DataGridViewCellMouseEventArgs e)
        {
            int indice = e.RowIndex;

            txtID.Text = dataGridView1.Rows[indice].Cells[0].Value.ToString();
            cbxTipo.Text = dataGridView1.Rows[indice].Cells[1].Value.ToString();
            txtNumero.Text = dataGridView1.Rows[indice].Cells[2].Value.ToString();
            txtPrecio.Text = dataGridView1.Rows[indice].Cells[3].Value.ToString();

        }

        private void txtBuscarT_TextChanged(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");

            conexion.Open();

            SqlCommand cmd = conexion.CreateCommand();

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM Habitaciones WHERE tipo like ('" + txtBuscarT.Text + "%')";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);

            dataGridView1.DataSource = dt;

            conexion.Close();
        }

        private void btnReporte_Click(object sender, EventArgs e)
        {
            ReporteHabitaciones frm = new ReporteHabitaciones();
            frm.Show();
        }
    }
}
