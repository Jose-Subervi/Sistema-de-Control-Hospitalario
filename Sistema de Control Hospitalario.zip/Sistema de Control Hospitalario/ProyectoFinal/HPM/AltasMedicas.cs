﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProyectoFinal.CSS;
using ProyectoFinal.DAL;

namespace ProyectoFinal.HPM
{
    public partial class AltasMedicas : Form
    {
        AltasMedicasDAL oAltasMedicasCSS;
        public AltasMedicas()
        {
            oAltasMedicasCSS = new AltasMedicasDAL();
            InitializeComponent();
            dataGridView1.DataSource = oAltasMedicasCSS.MostrarPacientes2().Tables[0];
            dataGridView2.DataSource = oAltasMedicasCSS.MostrarPacientes().Tables[0];
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            oAltasMedicasCSS.Agregar(RecuperarInformacion());
            dataGridView2.DataSource = oAltasMedicasCSS.MostrarPacientes().Tables[0];
            dataGridView1.DataSource = oAltasMedicasCSS.MostrarPacientes2().Tables[0];

        }

        private AltasMedicasCSS RecuperarInformacion()
        {
            AltasMedicasCSS oAltasMedicasCSS = new AltasMedicasCSS();

            int ID = 0; int.TryParse(txtID.Text, out ID);
            int Precio = 0; int.TryParse(txtPrecio.Text, out Precio);
            int Habitacion = 0; int.TryParse(txtHabitaciones.Text, out Habitacion);
            oAltasMedicasCSS.ID = ID;
            oAltasMedicasCSS.Fecha_salida = dateTimePicker2.Text;
            oAltasMedicasCSS.Precio = Precio;
            oAltasMedicasCSS.Fecha_ingreso = dateTimePicker1.Text;
            oAltasMedicasCSS.Paciente = txtPaciente.Text;
            oAltasMedicasCSS.Habitacion = Habitacion;

            DateTime fecha = Convert.ToDateTime(dateTimePicker2.Value);
            DateTime fecha1 = Convert.ToDateTime(dateTimePicker1.Value);

            double dias = fecha.Subtract(fecha1).Days;

             double calculo = dias * Precio;
             oAltasMedicasCSS.Precio_total = calculo;


            if (oAltasMedicasCSS.Precio_total <= 0) {             
                
                    MessageBox.Show("Las Fechas no coinciden...");               
            }
            else
            {
                MessageBox.Show("El total que tiene que pagar " + oAltasMedicasCSS.Paciente + " por la habitacion es: " + calculo);
            }




            txtID.Text = " ";
            txtPrecio.Text = " ";
            txtHabitaciones.Text = " ";
            txtPaciente.Text = " ";


            return oAltasMedicasCSS;


        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = oAltasMedicasCSS.MostrarPacientes2().Tables[0];
            dataGridView2.DataSource = oAltasMedicasCSS.MostrarPacientes().Tables[0];
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            oAltasMedicasCSS.Modificar(RecuperarInformacion());
            dataGridView2.DataSource = oAltasMedicasCSS.MostrarPacientes().Tables[0];
            dataGridView1.DataSource = oAltasMedicasCSS.MostrarPacientes2().Tables[0];
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            oAltasMedicasCSS.Eliminar(RecuperarInformacion());
            dataGridView2.DataSource = oAltasMedicasCSS.MostrarPacientes().Tables[0];
            dataGridView1.DataSource = oAltasMedicasCSS.MostrarPacientes2().Tables[0];
        }

        private void Seleccionar(object sender, DataGridViewCellMouseEventArgs e)
        {
            int indice = e.RowIndex;

            txtID.Text = dataGridView1.Rows[indice].Cells[0].Value.ToString();
            txtPaciente.Text = dataGridView1.Rows[indice].Cells[1].Value.ToString();
            txtHabitaciones.Text = dataGridView1.Rows[indice].Cells[2].Value.ToString();

        }

        private void Seleccionar2(object sender, DataGridViewCellMouseEventArgs e)
        {

            int indice = e.RowIndex;

            txtID.Text = dataGridView2.Rows[indice].Cells[0].Value.ToString();
            txtPrecio.Text = dataGridView2.Rows[indice].Cells[1].Value.ToString();
            txtPaciente.Text = dataGridView2.Rows[indice].Cells[2].Value.ToString();
            txtHabitaciones.Text = dataGridView2.Rows[indice].Cells[3].Value.ToString();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            Close();
            Principal2 frm = new Principal2();
            frm.Show();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtBuscarP_TextChanged(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");

            conexion.Open();

            SqlCommand cmd = conexion.CreateCommand();

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM Altas WHERE Paciente like ('" + txtBuscarP.Text + "%')";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);

            dataGridView2.DataSource = dt;

            conexion.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");

            conexion.Open();



            string CadenaSQL = "SELECT * FROM Altas WHERE Fecha_Ingreso BETWEEN '" + dateTimePicker4.Text + "' AND '" + dateTimePicker3.Text + "' ";


            SqlDataAdapter adaptador = new SqlDataAdapter(CadenaSQL, conexion);
            DataSet DS = new DataSet();

            adaptador.Fill(DS);

            dataGridView2.DataSource = DS.Tables[0];

            conexion.Close();
        }

        private void btnReporte_Click(object sender, EventArgs e)
        {
            ReporteAltasMedicas frm = new ReporteAltasMedicas();
            frm.Show();
        }
    }
}
