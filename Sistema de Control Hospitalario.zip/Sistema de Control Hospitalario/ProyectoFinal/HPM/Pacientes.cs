﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProyectoFinal.CSS;
using ProyectoFinal.DAL;

namespace ProyectoFinal.HPM
{
    public partial class Pacientes : Form
    {

        PacientesDAL oPacientesDAL;
        public Pacientes()
        {
            oPacientesDAL = new PacientesDAL();
            InitializeComponent();
            cbxAsegurado.Items.Add("Si");
            cbxAsegurado.Items.Add("No");
            dataGridView1.DataSource = oPacientesDAL.MostrarPacientes().Tables[0];

        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCreate_Click_1(object sender, EventArgs e)
        {

            oPacientesDAL.Agregar(RecuperarInformacion());
            dataGridView1.DataSource = oPacientesDAL.MostrarPacientes().Tables[0];

        }

        private PacientesCSS RecuperarInformacion()
        {
            PacientesCSS oPacientesCSS = new PacientesCSS();

            int ID = 0; int.TryParse(txtID.Text, out ID);
            int Cedula = 0; int.TryParse(txtCedula.Text, out Cedula);
            oPacientesCSS.ID = ID;
            oPacientesCSS.Nombre = txtNombre.Text;
            oPacientesCSS.Cedula = Cedula;
            oPacientesCSS.Aseguradora = cbxAsegurado.Text;

            txtID.Text = " ";
            txtCedula.Text = " ";
            txtNombre.Text = " ";
            cbxAsegurado.Text = " ";


            return oPacientesCSS;


        }

        private void btnRead_Click_1(object sender, EventArgs e)
        {
            dataGridView1.DataSource = oPacientesDAL.MostrarPacientes().Tables[0];
        }

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            oPacientesDAL.Modificar(RecuperarInformacion());
            dataGridView1.DataSource = oPacientesDAL.MostrarPacientes().Tables[0];
        }


        private void btnVolver_Click(object sender, EventArgs e)
        {
            Close();
            Principal frm = new Principal();
            frm.Show();
        }

        private void Seleccionar(object sender, DataGridViewCellMouseEventArgs e)
        {
            int indice = e.RowIndex;

            txtID.Text = dataGridView1.Rows[indice].Cells[0].Value.ToString();
            txtCedula.Text = dataGridView1.Rows[indice].Cells[1].Value.ToString();
            txtNombre.Text = dataGridView1.Rows[indice].Cells[2].Value.ToString();
            cbxAsegurado.Text = dataGridView1.Rows[indice].Cells[3].Value.ToString();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            oPacientesDAL.Eliminar(RecuperarInformacion());
            dataGridView1.DataSource = oPacientesDAL.MostrarPacientes().Tables[0];
        }

        private void Buscar(object sender, KeyEventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");

            conexion.Open();

            SqlCommand cmd = conexion.CreateCommand();

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM Pacientes WHERE nombre like ('" + txtBuscar.Text + "%')";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);

            dataGridView1.DataSource = dt;

            conexion.Close();
        }

        private void txtBuscarC_TextChanged(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");

            conexion.Open();

            SqlCommand cmd = conexion.CreateCommand();

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM Pacientes WHERE cedula like ('" + txtBuscarC.Text + "%')";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);

            dataGridView1.DataSource = dt;

            conexion.Close();
        }

        private void txtBuscarA_TextChanged(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server=localhost\\SQLEXPRESS; database=Proyect; integrated security=true");

            conexion.Open();

            SqlCommand cmd = conexion.CreateCommand();

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM Pacientes WHERE asegurado like ('" + txtBuscarA.Text + "%')";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);

            dataGridView1.DataSource = dt;

            conexion.Close();
        }

        private void btnReporte_Click(object sender, EventArgs e)
        {
            ReportePacientes frm = new ReportePacientes();
            frm.Show();
        }
    }

}
