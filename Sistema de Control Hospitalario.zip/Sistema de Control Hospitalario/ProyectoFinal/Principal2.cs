﻿using ProyectoFinal.HPM;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public partial class Principal2 : Form
    {
        public Principal2()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
            Principal frm = new Principal();
            frm.Show();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
            CitasMedicas frm = new CitasMedicas();
            frm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
            IngresosPacientes frm = new IngresosPacientes();
            frm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
            AltasMedicas frm = new AltasMedicas();
            frm.Show();
        }
    }
}
